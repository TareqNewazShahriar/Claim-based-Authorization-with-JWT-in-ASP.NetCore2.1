﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Jwt_Web_Client_Sample.Controllers
{
    public class HomeController : BaseController
    {
        public async Task<IActionResult> Index()
        {
            var x = await GetAsync<string>("home/index");

            return Content("from api: " + x);
        }

        [Authorize]
        public async Task<IActionResult> Authorized()
        {
            var x = await GetAsync<string>("home/allusers");

            return Content("from api: " + x);
        }

        [Authorize]
        public async Task<IActionResult> Protected()
        {
            var x = await GetAsync<string>("home/policyonly");

            return Content("from api: " + x);
        }
    }
}
