﻿using claim_based_api.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;

namespace claim_based_api
{
    public class SessionMiddleware : IMiddleware
    {
        public static List<IssuedToken> Tokens { get; set; }

        public SessionMiddleware()
        {
            if(Tokens == null)
                Tokens = new List<IssuedToken>();
        }

        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            if (Tokens.Exists(x=>x.Id == context.User.Claims.SingleOrDefault(c => c.Type == ClaimTypes.Email)?.Value))
            {
                await next(context);

                return;
            }

            await next(context);
            //context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
        }
    }
}
