﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace claim_based_api.Models
{
    public class IssuedToken
    {
        public string Id { get; set; }
        public string Jwt { get; set; }
        public DateTime Expires { get; set; }
        public JwtSecurityToken JwtSecurityToken { get; set; }
    }
}
