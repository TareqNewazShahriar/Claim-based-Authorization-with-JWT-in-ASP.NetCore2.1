﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace claim_based_api.Models
{
    public class Test_IssuedToken
    {
        [Key]
        public string UserEmail { get; set; }
        public string TokenString { get; set; }
        public DateTime Exp { get; set; }
    }
}
