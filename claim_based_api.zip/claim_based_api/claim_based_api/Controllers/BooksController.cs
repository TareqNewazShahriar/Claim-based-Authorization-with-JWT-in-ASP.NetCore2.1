﻿using claim_based_api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace claim_based_api.Controllers
{
    [Route("[controller]/[action]")]
    public class BooksController : ControllerBase
    {

        readonly AppDbContext _context;

        public BooksController(AppDbContext context)
        {
            _context = context;
        }

        private bool ValidateToken(string email)
        {
            var tokenRecord = _context.IssuedTokens.Find(email);
            if (tokenRecord != null)
            {
                tokenRecord.Exp = DateTime.UtcNow.AddSeconds(30);
                _context.SaveChanges();

                return true;
            }

            return false;
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            if (ValidateToken(HttpContext.User.Claims.SingleOrDefault(x => x.Type == ClaimTypes.Email)?.Value) == false)
                return Unauthorized();

            var currentUser = HttpContext.User;
            int userAge = 0;
            var resultBookList = new Book[] {
              new Book { Author = "Ray Bradbury", Title = "Fahrenheit 451", AgeRestriction = false },
              new Book { Author = "Gabriel García Márquez", Title = "One Hundred years of Solitude", AgeRestriction = false },
              new Book { Author = "George Orwell", Title = "1984", AgeRestriction = false },
              new Book { Author = "Anais Nin", Title = "Delta of Venus", AgeRestriction = true }
            };

            if (currentUser.HasClaim(c => c.Type == ClaimTypes.DateOfBirth))
            {
                DateTime birthDate = DateTime.Parse(currentUser.Claims.FirstOrDefault(c => c.Type == ClaimTypes.DateOfBirth).Value);
                userAge = DateTime.Today.Year - birthDate.Year;
            }

            if (userAge < 18)
            {
                resultBookList = resultBookList.Where(b => !b.AgeRestriction).ToArray();
            }

            return Ok(resultBookList);
        }

        [Authorize(Policy = "HasUniqueIdentity")]
        [HttpGet()]
        public List<Book> EldersBooks()
        {
            var allBooks = Get().Result as List<Book>;
            return allBooks.Where(x => x.AgeRestriction).ToList();
        }

        [HttpGet("{id}")]
        public Book Get(int id)
        {
            return new Book();
        }
    }
}
