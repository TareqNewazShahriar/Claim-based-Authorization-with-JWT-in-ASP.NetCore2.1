﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

namespace claim_based_api
{
    public abstract class AuthenticationMiddleware<TOptions> where TOptions : AuthenticationOptions, new()
    {
        private readonly RequestDelegate _next;

        public string AuthenticationScheme { get; set; }
        public TOptions Options { get; set; }
        public ILogger Logger { get; set; }
        public UrlEncoder UrlEncoder { get; set; }

        public async Task Invoke(HttpContext context)
        {
            AuthenticationScheme authScheme = new AuthenticationScheme(AuthenticationScheme, "asdf", null);

            var handler = CreateHandler();
            await handler.InitializeAsync(sc, context);
            try
            {
                var a = await handler.AuthenticateAsync();
                if (a.Succeeded)
                {
                    await _next(context);
                }
            }
            finally
            {
                try
                {
                    await handler.TeardownAsync();
                }
                catch (Exception)
                {
                    // Don't mask the original exception, if any
                }
            }
        }

        protected abstract AuthenticationHandler<TOptions> CreateHandler();
    }
}
