﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Jwt_Web_Client_Sample.Models
{
    public class ExternalLoginViewModel
    {
        public string Email { get; set; }
    }
}
